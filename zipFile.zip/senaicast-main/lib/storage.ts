import type { CorporateTVData, MediaContent, Announcement, TVDevice, InstitutionSettings, TVState } from "./types"

const STORAGE_KEY = "corporate-tv-data"

// Default data for initial setup
const defaultData: CorporateTVData = {
  institution: {
    name: "Escola SENAI Orlando Laviero Ferraiuolo",
    logoUrl: "/senai-logo-red-industrial-training.jpg",
  },
  contents: [
    {
      id: "1",
      type: "image",
      url: "/senai-industrial-workshop-students-learning-machin.jpg",
      name: "Oficina Industrial",
      duration: 10,
      order: 1,
      active: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: "2",
      type: "image",
      url: "/senai-technology-lab-students-computers-robotics.jpg",
      name: "Laboratório de Tecnologia",
      duration: 10,
      order: 2,
      active: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: "3",
      type: "image",
      url: "/senai-graduation-ceremony-students-certificates.jpg",
      name: "Formatura 2025",
      duration: 10,
      order: 3,
      active: true,
      createdAt: new Date().toISOString(),
    },
  ],
  announcements: [
    {
      id: "1",
      text: "Matrículas abertas para o segundo semestre de 2025! Garanta sua vaga.",
      priority: 1,
      active: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: "2",
      text: "Palestra sobre Indústria 4.0 - Dia 15/02 às 19h no Auditório Principal.",
      priority: 2,
      active: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: "3",
      text: "Horário de funcionamento: Segunda a Sexta, das 7h às 22h.",
      priority: 3,
      active: true,
      createdAt: new Date().toISOString(),
    },
  ],
  tvs: [
    {
      id: "tv-1",
      name: "TV Recepção",
      status: "active",
      lastContent: "Oficina Industrial",
      lastSeen: new Date().toISOString(),
      contentIds: [],
    },
    {
      id: "tv-2",
      name: "TV Corredor Principal",
      status: "active",
      lastContent: "Laboratório de Tecnologia",
      lastSeen: new Date().toISOString(),
      contentIds: [],
    },
  ],
  tvState: {
    currentContentIndex: 0,
    lastUpdated: new Date().toISOString(),
  },
}

// Get all data from localStorage
export function getData(): CorporateTVData {
  if (typeof window === "undefined") return defaultData

  const stored = localStorage.getItem(STORAGE_KEY)
  if (!stored) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultData))
    return defaultData
  }

  try {
    return JSON.parse(stored)
  } catch {
    return defaultData
  }
}

// Save all data to localStorage
export function saveData(data: CorporateTVData): void {
  if (typeof window === "undefined") return
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
}

// Institution Settings
export function getInstitution(): InstitutionSettings {
  return getData().institution
}

export function updateInstitution(settings: Partial<InstitutionSettings>): void {
  const data = getData()
  data.institution = { ...data.institution, ...settings }
  saveData(data)
}

// Media Contents
export function getContents(): MediaContent[] {
  return getData().contents.sort((a, b) => a.order - b.order)
}

export function getActiveContents(): MediaContent[] {
  return getContents().filter((c) => c.active)
}

// Simple UUID generator for compatibility
function generateUUID() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID()
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

export function addContent(content: Omit<MediaContent, "id" | "createdAt">): MediaContent {
  const data = getData()
  const newContent: MediaContent = {
    ...content,
    id: generateUUID(),
    createdAt: new Date().toISOString(),
  }
  data.contents.push(newContent)
  saveData(data)
  return newContent
}

export function updateContent(id: string, updates: Partial<MediaContent>): void {
  const data = getData()
  const index = data.contents.findIndex((c) => c.id === id)
  if (index !== -1) {
    data.contents[index] = { ...data.contents[index], ...updates }
    saveData(data)
  }
}

export function deleteContent(id: string): void {
  const data = getData()
  data.contents = data.contents.filter((c) => c.id !== id)
  saveData(data)
}

// Announcements
export function getAnnouncements(): Announcement[] {
  return getData().announcements.sort((a, b) => a.priority - b.priority)
}

export function getActiveAnnouncements(): Announcement[] {
  return getAnnouncements().filter((a) => a.active)
}

export function addAnnouncement(announcement: Omit<Announcement, "id" | "createdAt">): Announcement {
  const data = getData()
  const newAnnouncement: Announcement = {
    ...announcement,
    id: generateUUID(),
    createdAt: new Date().toISOString(),
  }
  data.announcements.push(newAnnouncement)
  saveData(data)
  return newAnnouncement
}

export function updateAnnouncement(id: string, updates: Partial<Announcement>): void {
  const data = getData()
  const index = data.announcements.findIndex((a) => a.id === id)
  if (index !== -1) {
    data.announcements[index] = { ...data.announcements[index], ...updates }
    saveData(data)
  }
}

export function deleteAnnouncement(id: string): void {
  const data = getData()
  data.announcements = data.announcements.filter((a) => a.id !== id)
  saveData(data)
}

// TV Devices
export function getTVs(): TVDevice[] {
  return getData().tvs
}

export function addTV(tv: Omit<TVDevice, "id" | "lastSeen">): TVDevice {
  const data = getData()
  const newTV: TVDevice = {
    ...tv,
    id: generateUUID(),
    lastSeen: new Date().toISOString(),
  }
  data.tvs.push(newTV)
  saveData(data)
  return newTV
}

export function updateTV(id: string, updates: Partial<TVDevice>): void {
  const data = getData()
  const index = data.tvs.findIndex((t) => t.id === id)
  if (index !== -1) {
    data.tvs[index] = { ...data.tvs[index], ...updates }
    saveData(data)
  }
}

export function deleteTV(id: string): void {
  const data = getData()
  data.tvs = data.tvs.filter((t) => t.id !== id)
  saveData(data)
}

// TV State
export function getTVState(): TVState {
  return getData().tvState
}

export function updateTVState(state: Partial<TVState>): void {
  const data = getData()
  data.tvState = { ...data.tvState, ...state, lastUpdated: new Date().toISOString() }
  saveData(data)
}
