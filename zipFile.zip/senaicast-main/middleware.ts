import { NextResponse, type NextRequest } from 'next/server'
import { updateSession } from '@/lib/supabase/middleware'

export async function middleware(request: NextRequest) {
    // Em alguns ambientes (proxy/rede interna), o site pode ser acessado via HTTP.
    // Isso quebra sessão do Supabase (cookies Secure) e alguns browsers de TV bloqueiam o conteúdo.
    // Então, em produção, forçamos HTTPS quando o proxy sinaliza 'x-forwarded-proto: http'.
    if (process.env.NODE_ENV === "production") {
        const forwardedProto = request.headers.get("x-forwarded-proto")
        if (forwardedProto === "http") {
            const url = request.nextUrl.clone()
            url.protocol = "https:"
            return NextResponse.redirect(url, 308)
        }
    }

    return await updateSession(request)
}

export const config = {
    matcher: [
        /*
         * Match all request paths except for the ones starting with:
         * - _next/static (static files)
         * - _next/image (image optimization files)
         * - favicon.ico (favicon file)
         * Feel free to modify this pattern to include more paths.
         */
        '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
    ],
}
