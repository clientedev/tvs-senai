# Manual Completo de Instalação Administrativa - SENAI Corporate TV

Este documento detalha o passo a passo para configurar, instalar e publicar o sistema de TV Corporativa do SENAI.

Este guia foi elaborado para que qualquer funcionário do SENAI possa replicar a instalação do zero.

---

## 1. Pré-requisitos

Antes de começar, certifique-se de que você tem acesso às seguintes contas e ferramentas:

1.  **Conta no GitHub**: [https://github.com/](https://github.com/) (Para armazenar o código).
2.  **Conta no Vercel**: [https://vercel.com/](https://vercel.com/) (Para colocar o site no ar). Use sua conta do GitHub para entrar.
3.  **Conta no Supabase**: [https://supabase.com/](https://supabase.com/) (Para o banco de dados). Use sua conta do GitHub para entrar.
4.  **VS Code instalado**: Editor de código.
5.  **Node.js instalado**: Para rodar o projeto localmente se necessário.

---

## 2. Configurando o Banco de Dados (Supabase)

O Supabase será o "cérebro" do sistema, armazenando os vídeos, avisos e configurações das TVs.

### Passo 2.1: Criar um Projeto
1.  Acesse o [Dashboard do Supabase](https://supabase.com/dashboard/projects).
2.  Clique em **"New Project"**.
3.  Selecione sua organização (se não tiver, crie uma).
4.  Preencha os dados:
    *   **Name**: `senaicast` (ou outro de sua preferência).
    *   **Database Password**: Crie uma senha forte e **GUARDE-A** (você vai precisar depois).
    *   **Region**: Selecione `South America (São Paulo)` para menor latência.
5.  Clique em **"Create new project"**. Aguarde alguns minutos até o projeto estar pronto (ficará verde).

### Passo 2.2: Configurar a Estrutura do Banco (Tabelas)
1.  No menu lateral esquerdo do Supabase, clique em **SQL Editor** (ícone de terminal `>_`).
2.  Clique em **"New Query"** (folha em branco).
3.  Copie **TODO** o conteúdo do arquivo `supabase_setup_complete.sql` que está na pasta deste projeto.
4.  Cole o conteúdo no editor do Supabase.
5.  Clique no botão **"Run"** (canto inferior direito do editor).
    *   *Resultado esperado*: Uma mensagem "Success" deve aparecer. Isso criou todas as tabelas e permissões necessárias.

### Passo 2.3: Configurar o Armazenamento de Arquivos
1.  No menu lateral esquerdo, clique em **Storage** (ícone de balde).
2.  Clique em **"New Bucket"**.
    *   **Name**: `corporate-media`
    *   **Public bucket**: **ATIVADO** (Importante! Marque a opção "Public bucket").
    *   Clique em **Save**.
3.  Crie outro bucket:
    *   Clique em **"New Bucket"**.
    *   **Name**: `app-assets`
    *   **Public bucket**: **ATIVADO**.
    *   Clique em **Save**.

### Passo 2.4: Pegar as Credenciais
Você vai precisar de dois códigos para conectar o site ao banco.
1.  No menu lateral esquerdo, clique no ícone de engrenagem **Project Settings**.
2.  Clique na aba **"API"**.
3.  Anote (copie para um bloco de notas) os seguintes valores na seção **Project URL** e **Project API keys**:
    *   `Project URL` (Começa com `https://...supabase.co`)
    *   `anon` `public` API Key (Começa com `eyJ...`. **NÃO USE a service_role**).

---

## 3. Configurando o Projeto (Código)

Agora vamos conectar o código ao banco de dados que você acabou de criar.

### Passo 3.1: Arquivo de Variáveis de Ambiente
1.  No seu projeto (VS Code), localise o arquivo `.env.example` (se existir) ou crie um arquivo chamado `.env.local` na raiz do projeto.
2.  Edite esse arquivo com as credenciais que você pegou no Passo 2.4:

```env
NEXT_PUBLIC_SUPABASE_URL=Sua_Project_URL_Aqui
NEXT_PUBLIC_SUPABASE_ANON_KEY=Sua_Anon_Key_Aqui
NEXT_PUBLIC_SITE_URL=https://seu-projeto.vercel.app
```

> **Importante (Smart TV / HTTPS):** Use sempre a URL **HTTPS** do site em produção.
> Se você definir `NEXT_PUBLIC_SITE_URL`, o sistema passa a gerar os links das TVs usando essa URL (evita links em HTTP e possíveis alertas de “site inseguro / conteúdo bloqueado”).

### Passo 3.2: Instalar Dependências (Opcional - Apenas se for rodar localmente)
Se quiser testar no seu computador antes de enviar:
1. Abra o terminal no VS Code (`Ctrl + '`).
2. Digite: `npm install`
3. Digite: `npm run dev`
4. Acesse `http://localhost:3000` no seu navegador.

---

## 4. Publicando o Site (Vercel)

Esta é a etapa final para colocar o sistema no ar.

1.  Acesse o [Dashboard da Vercel](https://vercel.com/dashboard).
2.  Clique em **"Add New..."** -> **"Project"**.
3.  Selecione o repositório `senaicast` (importado do seu GitHub). Clique em **"Import"**.
4.  Na tela de configuração ("Configure Project"):
    *   **Framework Preset**: Deixe como `Next.js`.
    *   **Environment Variables** (Variáveis de Ambiente): Clique para expandir.
    *   Adicione as mesmas variáveis que você configurou no Passo 3.1:
        *   **NAME**: `NEXT_PUBLIC_SUPABASE_URL` | **VALUE**: (Sua URL do Supabase) -> Clique em Add.
        *   **NAME**: `NEXT_PUBLIC_SUPABASE_ANON_KEY` | **VALUE**: (Sua Key Anon do Supabase) -> Clique em Add.
5.  Clique em **"Deploy"**.

A Vercel vai construir o site. Aguarde (pode levar 1 a 2 minutos). Quando terminar, você verá uma tela com fogos de artifício e o link do seu site (ex: `senaicast.vercel.app`).

---

## 5. Como Usar

### 5.1 Acessar o Painel Administrativo
*   Acesse `https://seu-projeto.vercel.app/admin`.
*   Aqui você pode adicionar vídeos, imagens, avisos e cadastrar as TVs.

### 5.2 Configurar uma TV
1.  No Painel Admin, vá em "TVs" e clique em "Adicionar TV".
2.  Dê um nome (ex: "Recepção").
3.  O sistema vai gerar um **link único**.
4.  Na Smart TV (ou computador ligado à TV), abra o navegador e acesse esse link.
5.  **Dica**: Pressione `F11` no teclado para deixar em tela cheia (Modo Kiosk).

Pronto! O sistema está operando e atualiza em tempo real. Qualquer mudança no Admin aparecerá instantaneamente na TV.
