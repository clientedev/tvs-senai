# Guia de Hospedagem (Deployment)

Este projeto foi construído com **Next.js** e **Supabase**, e a forma mais fácil e recomendada de hospedar é usando a **Vercel** (criadores do Next.js).

## Pré-requisitos
1. Uma conta no [Supabase](https://supabase.com/).
2. Uma conta na [Vercel](https://vercel.com/) (pode criar com Github/Gitlab/Bitbucket).
3. O código do projeto salvo no **GitHub**.

---

## 1. Preparar o Repositório (GitHub)
Se você ainda não enviou seu código para o GitHub:
1. Crie um novo repositório no GitHub.
2. No terminal do VS Code, execute:
   ```bash
   git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
   git add .
   git commit -m "Versão final para produção"
   git push -u origin main
   ```

## 2. Configurar na Vercel
1. Acesse o [Dashboard da Vercel](https://vercel.com/dashboard).
2. Clique em **"Add New..."** > **"Project"**.
3. Selecione o repositório do seu projeto no GitHub e clique em **Import**.
4. Na tela de configuração ("Configure Project"):
   - **Framework Preset**: Deve detectar automaticamente como `Next.js`.
   - **Root Directory**: Deixe como `./`.
   - **Environment Variables**: Aqui é o passo CRÍTICO.

### Variáveis de Ambiente
Você precisa adicionar as mesmas variáveis que colocou no arquivo `.env.local`:

| Name | Value |
|------|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | *Sua URL do Projeto Supabase* |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | *Sua Anon Key do Supabase* |
| `NEXT_PUBLIC_SITE_URL` | *URL pública do seu site (HTTPS), ex: `https://senaicast.vercel.app` ou seu domínio* |

Copie os valores do seu arquivo `.env.local` ou do Dashboard do Supabase e adicione um por um.

5. Clique em **Deploy**.

## 3. Finalização
A Vercel vai construir o projeto e, em alguns minutos, fornecerá uma URL pública (ex: `corporate-tv-senai.vercel.app`).

### Configuração Pós-Deploy
1. **Logo e Imagens**: Verifique se o upload e visualização continuam funcionando. As políticas de segurança (RLS) que configuramos já devem permitir isso.
2. **TVs**: Ao criar uma nova TV no Admin em produção, o link gerado será o da produção. Lembre-se de atualizar as TVs físicas para usar a nova URL.
3. **Admin User**: Seu usuário criado no Supabase Auth continua valendo, pois o banco de dados é o mesmo.

### Observação (HTTPS / “site inseguro”)
Para evitar que navegadores de Smart TV exibam “site inseguro” e bloqueiem conteúdo, publique sempre em **HTTPS**.
Defina `NEXT_PUBLIC_SITE_URL` com a **URL HTTPS canônica** para que os links das TVs sejam gerados corretamente.
