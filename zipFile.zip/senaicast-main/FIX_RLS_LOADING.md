# Correção do Problema de Carregamento Infinito

## Problema Identificado

O carregamento infinito ocorre porque as **políticas RLS (Row Level Security)** do Supabase estão bloqueando o acesso às tabelas quando o usuário não está autenticado (página anônima/TV).

## Solução

Execute o arquivo `supabase_rls_policies.sql` no **SQL Editor do Supabase** para configurar as políticas de segurança corretas.

### Passos:

1. Acesse o [Dashboard do Supabase](https://app.supabase.com)
2. Selecione seu projeto
3. Vá em **SQL Editor** no menu lateral
4. Clique em **New Query**
5. Copie e cole o conteúdo do arquivo `supabase_rls_policies.sql`
6. Clique em **Run** para executar

### O que o script faz:

- ✅ Habilita RLS nas tabelas necessárias
- ✅ Permite leitura pública da tabela `tv_devices` por token
- ✅ Permite atualização do campo `last_seen` para rastreamento
- ✅ Permite leitura pública das configurações da instituição
- ✅ Permite leitura pública dos conteúdos atribuídos à TV
- ✅ Permite leitura pública apenas dos conteúdos e anúncios ativos

## Após Executar o SQL

Após executar o script SQL, o carregamento deve funcionar corretamente:

1. ✅ Páginas anônimas funcionarão
2. ✅ TVs sem cache funcionarão
3. ✅ Novos tokens funcionarão imediatamente

## Teste

Teste acessando uma URL como:
```
https://senaicast.vercel.app/tv?token=SEU_TOKEN_AQUI
```

## Nota de Segurança

As políticas criadas permitem leitura pública dos dados necessários para as TVs. Isso é seguro porque:
- Apenas dados necessários para exibição são expostos
- Conteúdos e anúncios inativos não são expostos
- Apenas leitura está permitida (sem edição/deleção)
- O token funciona como uma chave de acesso

## Se o Problema Persistir

Se após executar o SQL o problema continuar:

1. Verifique se o token foi gerado corretamente no admin
2. Verifique o console do navegador para erros específicos
3. Certifique-se de que as variáveis de ambiente estão configuradas no Vercel
4. Verifique se as tabelas existem no Supabase

## Erros Comuns

- **"TV não encontrada ou token inválido"**: Verifique se o token existe no banco
- **"Erro de permissão"**: Execute o arquivo SQL de políticas RLS
- **"Tempo limite excedido"**: Verifique a conexão com o Supabase